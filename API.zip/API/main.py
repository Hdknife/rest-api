from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from utili import (SessionLocal, StudentCreate, StudentResponse,
                  StudentDB, CourseCreate, CourseResponse,
                  CourseDB, EnrollmentCreate, EnrollmentDB,
                  validate_email)
from typing import List
from fastapi_pagination import Page, add_pagination, paginate

app = FastAPI()

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# API Endpoints
@app.post("/students/", response_model=StudentResponse)
def create_student(student: StudentCreate, db: Session = Depends(get_db)):
    if not validate_email(student.email):
        raise HTTPException(status_code=400, detail="Invalid email format")
    db_student = StudentDB(name=student.name, email=student.email)
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student

@app.post("/courses/", response_model=CourseResponse)
def create_course(course: CourseCreate, db: Session = Depends(get_db)):
    db_course = CourseDB(title=course.title, description=course.description)
    db.add(db_course)
    db.commit()
    db.refresh(db_course)
    return db_course

@app.post("/enroll/")
def enroll_student(enrollment: EnrollmentCreate, db: Session = Depends(get_db)):
    student = db.query(StudentDB).filter(StudentDB.id == enrollment.student_id).first()
    course = db.query(CourseDB).filter(CourseDB.id == enrollment.course_id).first()
    
    if not student or not course:
        raise HTTPException(status_code=404, detail="Student or Course not found")
    
    db_enrollment = EnrollmentDB(student_id=enrollment.student_id, course_id=enrollment.course_id)
    db.add(db_enrollment)
    db.commit()
    return {"message": "Enrollment successful"}

@app.get("/students/{id}", response_model=StudentResponse)
def get_student(id: int, db: Session = Depends(get_db)):
    student = db.query(StudentDB).filter(StudentDB.id == id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    student_response = StudentResponse(
        id=student.id,
        name=student.name,
        email=student.email,
        courses=[CourseCreate(title=e.course.title, description=e.course.description) for e in student.enrollments]
    )
    return student_response

@app.get("/courses/{id}", response_model=CourseResponse)
def get_course(id: int, db: Session = Depends(get_db)):
    course = db.query(CourseDB).filter(CourseDB.id == id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    
    course_response = CourseResponse(
        id=course.id,
        title=course.title,
        description=course.description,
        students=[StudentCreate(name=e.student.name, email=e.student.email) for e in course.enrollments]
    )
    return course_response


@app.get("/students/", response_model=Page[StudentResponse])
def get_all_students(db: Session = Depends(get_db)):
    students = db.query(StudentDB).all()
    student_responses = [
        StudentResponse(
            id=s.id,
            name=s.name,
            email=s.email,
            courses=[CourseCreate(title=e.course.title, description=e.course.description) for e in s.enrollments]
        ) for s in students
    ]
    return paginate(student_responses)


@app.get("/courses/", response_model=Page[CourseResponse])
def get_all_courses(db: Session = Depends(get_db)):
    courses = db.query(CourseDB).all()
    course_responses = [
        CourseResponse(
            id=c.id,
            title=c.title,
            description=c.description,
            students=[StudentCreate(name=e.student.name, email=e.student.email) for e in c.enrollments]
        ) for c in courses
    ]
    return paginate(course_responses)

add_pagination(app)