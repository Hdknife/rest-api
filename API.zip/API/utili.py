from pydantic import BaseModel, EmailStr
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
from typing import List
import re

# Database setup
DATABASE_URL = "sqlite:///student_course.db"  # Use PostgreSQL in production
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Database Models
class StudentDB(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    enrollments = relationship("EnrollmentDB", back_populates="student")

class CourseDB(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text)
    enrollments = relationship("EnrollmentDB", back_populates="course")

class EnrollmentDB(Base):
    __tablename__ = "enrollments"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    enrolled_on = Column(DateTime, default=datetime.utcnow)
    student = relationship("StudentDB", back_populates="enrollments")
    course = relationship("CourseDB", back_populates="enrollments")

# Create database tables
Base.metadata.create_all(bind=engine)

# Pydantic Models
class StudentCreate(BaseModel):
    name: str
    email: EmailStr

class CourseCreate(BaseModel):
    title: str
    description: str | None = None

class EnrollmentCreate(BaseModel):
    student_id: int
    course_id: int

class StudentResponse(BaseModel):
    id: int
    name: str
    email: str
    courses: List[CourseCreate] = []

class CourseResponse(BaseModel):
    id: int
    title: str
    description: str | None
    students: List[StudentCreate] = []

# Email validation function
def validate_email(email: str) -> bool:
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(pattern, email))